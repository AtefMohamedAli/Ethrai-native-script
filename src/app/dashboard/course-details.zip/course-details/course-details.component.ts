import { ViewContainerRef, AfterViewInit, ApplicationRef, ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, NgZone, OnChanges, OnInit, SimpleChanges, ViewChild, HostListener } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { RouterExtensions } from '@nativescript/angular';
import { AndroidActivityEventData, AndroidApplication, Connectivity, Dialogs, Frame, knownFolders, Page, path, WebView } from '@nativescript/core';
import { DashboardService } from '../dashboard.service';
import { registerElement } from "@nativescript/angular";
// import { Video } from '@nstudio/nativescript-exoplayer';
import { SelectedItemService } from '../selected-item-service';
// import { PDFViewNg } from 'nativescript-pdfview-ng';
import * as share from '@nativescript/social-share'
import { GlobalService } from '../../shared/services/global.service';
import { localize } from '@nativescript/localize';
import { EnrolledCourse } from '../../shared/models/enrolled-course';
import { Utils } from "@nativescript/core";
import { PaymentService } from '../../payment/payment.service';
import { AccountService } from '../../account/account.service';
import { environment } from '../../../../environments/environment';
import { LoadEventData } from '@nativescript/core';
// Removed: import { LoadFinishedEventData, WebConsoleEventData, WebViewExt, LoadEventData, WebViewEventData } from '@nota/nativescript-webview-ext';
import { WebViewSource } from './web-view-source';
import { Observable, Subscription } from 'rxjs';
import { switchMap, map, concatMap, tap, retryWhen, delay } from 'rxjs/operators';
import { isAndroid, isIOS } from "@nativescript/core";
// import { InAppPurchaseManager, InAppPurchaseResultCode, InAppPurchaseStateUpdateListener,
//     InAppOrderResult,InAppPurchaseTransactionState, InAppProduct ,InAppListProductsResult,
//     InAppPurchaseType,InAppOrderConfirmResult } from 'nativescript-in-app-purchase'
import { ModalDialogService } from '@nativescript/angular';
import { CourseRatingModalComponent } from '../course-rating-modal/course-rating-modal.component';
import { FirebaseEventService } from '~/app/shared/services/firebase.event.service';
import { Application, ApplicationEventData, LaunchEventData, OrientationChangedEventData, UnhandledErrorEventData } from "@nativescript/core";
import { SelectedIndexChangedEventData } from '@nativescript/core/ui/tab-view';
import { AlibabaHTMLGenerator } from './AlibabaHTMLGenerator';
import { File } from "@nativescript/core/file-system";
import { InlineVideoWebView } from './inline-video-webview';

// Register custom WebView with inline video playback support
registerElement("InlineVideoWebView", () => InlineVideoWebView);
// registerElement("Video", () => Video);
// registerElement('PDFViewNg', () => PDFViewNg);

@Component({
    moduleId: module.id,
    selector: 'course-details',
    templateUrl: './course-details.component.html',
    styleUrls: ['./course-details.component.css'],
})


export class CourseDetailsComponent implements OnInit {
    // @ViewChild('pdf') pdf:PDFViewNg
    @ViewChild('videoWebView') videoWebViewRef: ElementRef<WebView>;
    //  @ViewChild('webViewExt') webView:ElementRef
    // webViewExt:WebViewExt

    Math: any;
    courseId: string;
    course: any = {};
    durationHours: number = 0;
    durationMinutes: number = 0;
    skillsIDs: string[];
    skills: any[] = [];
    feedbacks: any[] = [];
    isLoading: boolean;
    progressPercentage: number = 0;
    courseDetails: any[] = [];
    parents: any[];
    childern: any[];
    collapsableParents: any[];
    collapsableSubParents: any[];
    selectedItem: any;
    url: string;
    clickedd = {}; s;
    clickedd1 = {}; b;
    myCourses: any[];
    paymentNotCompleted: boolean = false;
    paymentCompleted: boolean = false;
    paymentWaiting: boolean = false;
    isCourseFinished: boolean = false;
    isAlreadyEnrolled: boolean = false;
    showEnrollButton: boolean = false;
    showCartButton: boolean = false;
    showCertificateButton: boolean = false;
    showWaitCertificateButton: boolean;
    isAlreadyInCart: boolean;
    isEthrai: boolean;
    tenantName: any;
    isVideoLoading: boolean;
    subsVar: Subscription;
    isAutoPlay: boolean;
    isVideoFinished: boolean;
    assessmentQuestionIndex: number;
    assessmentQuestionsNo: any;
    assessmentProgressPercent: number;
    assessmentQuestions: any;
    selectedAnswerId: any;
    correctAnswerId: any;
    isFirstAnswerAttempt: any = true;
    correctAnswersCount: number = 0;
    correctAnswersPercentage: number;
    showResult: boolean = false;
    currentVideoSecond: number = 0;
    similarCourses: any[];
    isAndroid: boolean;
    showWaitButton: boolean;
    flattenedDetails: any[] = [];
    attendedSeconds: any;
    certificateURL: any;
    //private inAppPurchaseManager: InAppPurchaseManager;
    showAppleBuyButton: boolean;
    certSubscription: Subscription;
    isIOS: boolean;
    isConfirmed: boolean;
    isQueryProduct: boolean;
    item
    shoppingCartItemsCount: number;
    showProcessingButton: boolean;
    loggedDuration: string;
    LabelsArray: any = [];
    showSimilarCourse: boolean;
    detailId: string;
    isVideoPlayed: boolean;
    isQuestionAnswered: boolean = false;
    // Intl polyfill for iOS - safely handles undefined/null
    intl = { format: (n: any) => n != null ? String(n) : '0' };

    // Helper for number formatting
    formatNumber(n: any): string {
        return n != null ? String(n) : '0';
    }

    logVal(val: any, tag: string): any {
        console.log(`DEBUG [${tag}]:`, val);
        return val;
    }
    publishDate: string;
    webview: any;
    showReviewForm: boolean;
    selectedTabIndex: any = 1;
    urlProtected: any;
    subtitle: any[] = [];
    videoPlayerSrc: string = '';  // Bound to WebViewExt [src] in template
    constructor(private page: Page, private route: Router, private router: RouterExtensions, private activatedRoute: ActivatedRoute, private dashboardService: DashboardService
        , private selectedItemService: SelectedItemService, public globalService: GlobalService, private paymentService: PaymentService,
        private accountService: AccountService, private modalService: ModalDialogService, private firebaseEventService: FirebaseEventService,
        private vcRef: ViewContainerRef, private zone: NgZone) {


        page.actionBarHidden = true;
        //this.courseId =this.activatedRoute.snapshot.paramMap.get("courseId");
        this.activatedRoute.paramMap.subscribe(params => {
            this.courseId = params.get('courseId')
        })
        this.activatedRoute.paramMap.subscribe(params => {
            this.detailId = params.get('detailId')
        })
        this.Math = Math;
        this.isAutoPlay = this.globalService.isAutoPlayNextVideo();
        this.assessmentQuestionIndex = 0;
        this.isEthrai = this.globalService.isEthrai;
        this.isConfirmed = false;
        //this.protected()
    }


    clickme(item) {
        this.clickedd = item;
    }
    uclickme(item) {
        this.clickedd = {};
    }
    clickme1(item) {
        this.clickedd1 = item;
    }
    uclickme1(item) {
        this.clickedd1 = {};
    }

    onError(event: ErrorEvent) {
        console.dir(event)
    }
    goBack() {
        if (isIOS && this.webview) {
            try {
                (this.webview as any).ios?.evaluateJavaScriptCompletionHandler("Video.remove()", (result: any, error: any) => {
                    console.log("res go back", result);
                });
            } catch (e) { console.log('goBack JS error:', e); }
        }
        if (this.globalService.previousURL?.includes("/payment-success")) {
            this.router.navigate(['/my-products'])
        } else {
            Frame.topmost().goBack();
        }
    }

    templateSelector(item: any, index: number, items: any): string {
        if (index == 0) {
            return !item.expanded ? 'expanded' : 'default';
        }
        return item.expanded ? 'expanded' : 'default';
    }

    ngOnInit() {
        this.isAndroid = isAndroid;
        this.isIOS = isIOS;
        //comment this To Try AliBabaVideo
        // if(isAndroid){
        //     Application.android.on(AndroidApplication.activityPausedEvent, function (args: AndroidActivityEventData) {
        //         this.webview.emitToWebView('pauseVideo',null)
        //     },this);
        // }
        this.shoppingCartItemsCount = this.globalService.shoppinCartItemsCount
        this.page.on('loaded', () => {
            this.subsVar = this.onItemSelected();
            this.getSubtitle(this.courseId)

            if (isIOS) {
                //  this.getInAppPurchaseManager();
            }
            // this.webview?.reload()
        });
        this.getUserFeedbacks();
        if (this.globalService.isLoggedIn) {
            if (this.isEthrai) {
                this.firebaseEventService.logScreenViewedEvent(this.globalService.isLoggedIn, this.globalService.getUserStats(), 'course_page', this.globalService.getUserProfile());
            }
            this.getAllCourseInfo().subscribe(res => {
                this.handleSubscriptionToCourse();
            })

        } else {
            this.getCourseDetails();
            this.firebaseEventService.logScreenViewedEvent(false, null, 'course_page', null);

        }
        this.getSimilarCourses();



    }
    protected(id) {
        this.isLoading = true;
        this.dashboardService.protected(id).subscribe(
            res => {
                this.urlProtected = (res as any).details[0]?.alibabaPlayInfo;
            }
        )
        // this.showEnrollButton=true;
    }
    getSubtitle(id) {
        this.isLoading = true;
        this.dashboardService.getSubtitle(id, 0).subscribe(
            res => {
                this.subtitle = (res as any);
            }
        )
    }
    onLoadFinishedAliBaba(args: LoadEventData) {
        console.log('DEBUG onLoadFinishedAliBaba called');
        this.webview = args.object;

        // InlineVideoWebView handles iOS WKWebView inline playback configuration at creation time
        // No additional configuration needed here

        // Load video content if available
        if (this.urlProtected?.streamingSources?.length > 0) {
            this.setWebViewAliBabaSrc();
        }

        this.registerCustomEvents();
    }
    registerCustomEvents() {
        if (this.webview) {
            this.webview.on("timechange", (msg: any) => {
                this.currentVideoSecond = Math.round(msg.data)
                console.log('timechange event:', this.currentVideoSecond);

            });
            this.webview.on("percentwatchedchanged", (msg) => {
                console.log('percentwatchedchanged')
            });
            this.webview.on("end", (msg) => {
                if (this.isAutoPlay) {
                    this.isVideoFinished = true;
                }
                if (this.globalService.isEthrai) {
                    this.firebaseEventService.logVideoStartedorCompletedEvent('course_videocompleted', 'course_page', this.course, this.selectedItem.nameAr, this.loggedDuration, this.progressPercentage, this.getItemUnit(this.selectedItem))
                }
                this.setCurrentElementInfo(this.currentVideoSecond);
                let selectedItemIndex = this.flattenedDetails.indexOf(this.selectedItem);
                if (selectedItemIndex + 1 < this.flattenedDetails?.length) {
                    this.selectedItem = this.flattenedDetails[selectedItemIndex + 1];
                    this.selectedItemService.emit(this.flattenedDetails[selectedItemIndex + 1])
                }
            });
            this.webview.on("percentwatchedchanged", (msg) => {
                this.setTrackedItem(this.selectedItem.id)
            });
            this.webview.on("pause", (msg: any) => {
                this.isVideoPlayed = false;
                this.setCurrentElementInfo(this.currentVideoSecond);
            });
            this.webview.on("timechange", (msg: any) => {
                this.currentVideoSecond = Math.round(msg.data)
            });
            this.webview.on("play", (msg: any) => {
                this.isVideoPlayed = true;
                if (this.globalService.isEthrai) {
                    this.firebaseEventService.logVideoStartedorCompletedEvent('course_videostarted', 'course_page', this.course, this.selectedItem.nameAr, this.loggedDuration, this.progressPercentage, this.getItemUnit(this.selectedItem))
                }
            });
        }
        else {
            console.log('nsWebViewBridge is not available');
        }
    }
    Alibaba() {
        console.log('DEBUG Alibaba(): urlProtected keys =', this.urlProtected ? Object.keys(this.urlProtected) : 'null');
        console.log('DEBUG Alibaba(): urlProtected.streamingSources =', this.urlProtected?.streamingSources);
        console.log('DEBUG Alibaba(): urlProtected.playInfoList =', this.urlProtected?.playInfoList);
        if (!this.urlProtected || !this.urlProtected.streamingSources || this.urlProtected.streamingSources.length === 0) {
            return '<h2>No video sources available</h2>';
        }
        const coverUrl = this.urlProtected.coverUrl || '';
        const videoSources = this.urlProtected.streamingSources;
        let filtered = [];
        if (this.subtitle && this.subtitle.length > 0) {
            filtered = this.subtitle.find(x => x.id === this.selectedItem.id);
        }
        const htmlGenerator = new AlibabaHTMLGenerator(coverUrl, videoSources, filtered);
        return htmlGenerator.generateHTML();
    }
    getSimilarCourses() {
        this.dashboardService.getSimilarCourses(5, this.courseId).subscribe(
            res => {
                this.similarCourses = res as any[]
                if (this.similarCourses.length && (this.isEthrai || !this.globalService.isLoggedIn)) {
                    this.firebaseEventService.logCourseImpressionsEvent('course_page', this.similarCourses, 'training')
                }
                setTimeout(() => {
                    this.showSimilarCourse = true
                }, 2000);
            }
        )
    }

    getAllCourseInfo() {
        this.isLoading = true;
        if (this.isEthrai) {
            return this.dashboardService.getCourseDetails(this.courseId)
                .pipe(
                    tap(res => { this.isLoading = false, this.handleCourseDetails(res) }),
                    concatMap((res) => this.dashboardService.getInvoicedProducts()),
                    tap(res => this.handleInvoicedProducts(res)),
                )
        } else {
            return this.dashboardService.getCourseDetails(this.courseId)
                .pipe(
                    tap(res => { this.isLoading = false, this.handleCourseDetails(res) })
                )
        }

    }

    handleInvoicedProducts(res) {
        let invoices = res as any[];
        this.paymentNotCompleted = !invoices.some(m => m.productId === this.courseId && m.productType === "Course"
            ||
            (m.courseIds?.includes(this.courseId) && m.productType === "CoursePath"))
            ||
            !invoices.some(m => (m.productId === this.courseId && m.productType === "Course" ||
                (m.courseIds?.includes(this.courseId) && m.productType === "CoursePath")) && ["PmtCompleted", "PmtUpdated", "PmtNew"].includes(m.status))
        // || 
        // invoices.some(m => m.productId === this.courseId && m.productType === "Course" && ["PmtExpired", "BillExpired", "PmtNotCompleted","PmtReversal"].includes(m.status))     

        this.paymentCompleted = invoices.some(m => m.productId === this.courseId && m.productType === "Course" && m.status === "PmtCompleted")
        // console.log("this.paymentNotCompleteddd",!invoices.some(m => m.productId === this.courseId && m.productType === "Course"),this.paymentNotCompleted )
        // console.log("this.paymentNotCompleted",!invoices.some(m => m.productId === this.courseId && m.productType === "Course" && ["PmtCompleted", "PmtUpdated", "PmtNew"].includes(m.status) ))
        // console.log("this.paymentNotCompleted",invoices.some(m => m.productId === this.courseId && m.productType === "Course" && ["PmtExpired", "BillExpired", "PmtNotCompleted","PmtReversal"].includes(m.status))  )  
        // console.log( this.paymentNotCompleted,this.paymentCompleted)
    }

    handleCourseDetails(res) {
        this.course = (res as any);
        let totalSeconds = this.course?.course?.numberOfSeconds || 0;
        let minutes = Math.floor(totalSeconds / 60);
        this.durationHours = Math.floor(minutes / 60);
        this.durationMinutes = (minutes) % 60;

        let loggedHours = this.durationHours < 10 ? '0' + this.durationHours : this.durationHours
        let loggedMin = this.durationMinutes < 10 ? '0' + this.durationMinutes : this.durationMinutes
        this.loggedDuration = loggedHours + 'h ' + loggedMin + 'm'
        this.skillsIDs = this.course?.course?.skillIds;

        if (this.course?.course?.publishDate) {
            try {
                this.publishDate = new Intl.DateTimeFormat('ar-SA').format(new Date(this.course.course.publishDate));
            } catch (e) {
                this.publishDate = '';
            }
        } else {
            this.publishDate = '';
        }

        if (this.course.userFeedback) {
            this.feedbacks.push(this.course.userFeedback)
        }
        if (this.course.enrollment) {
            this.isAlreadyEnrolled = true;
            this.showReviewForm = true;
            this.attendedSeconds = this.course.enrollment.attendedSeconds || 0;
            this.handleSubscriptionToCourse();

            let requiredSeconds = this.course.course.numberOfSecondsRequiredToAttend || 1; // prevent div by zero
            let calcPercent = (this.attendedSeconds / requiredSeconds) * 100;

            if (isNaN(calcPercent) || !isFinite(calcPercent)) {
                this.progressPercentage = 0;
            } else {
                this.progressPercentage = calcPercent > 100 ? 100 : Number(calcPercent.toFixed(2));
            }

        }
        this.dashboardService.getSkills().subscribe(
            res => {
                this.skills = (res as any[]).filter(skill => {
                    if (this.skillsIDs?.includes(skill.id)) {
                        return skill;
                    }
                });
            }
        );
        this.flat(this.course);
        let currentItem;
        if (this.detailId) {
            currentItem = this.flattenedDetails.find(el => el.id == this.detailId);
        } else if (this.isAlreadyEnrolled) {

            if (this.course.enrollment?.currentCourseDetailId) {
                currentItem = this.flattenedDetails.find(item => item.id == this.course.enrollment?.currentCourseDetailId);
                currentItem ? currentItem = currentItem : currentItem = this.flattenedDetails[0]
            } else {
                currentItem = this.flattenedDetails[0]//.find(item=>item.type=='Video');
            }
            //  this.traverseById(this.course);
        } else {
            // this.traverse(this.course)
            currentItem = this.flattenedDetails.find(item => item.type == 'Video' && item.isAvailableWithoutRegister);

        }
        if (this.globalService.isEthrai || !this.globalService.isLoggedIn) {
            this.firebaseEventService.logCourseDetailsImpressionEvent("view_item", 'course_page', this.course, currentItem?.nameAr, this.loggedDuration, this.progressPercentage, this.getItemUnit(currentItem))
        }

        if (currentItem) {
            this.selectedItem = null;
            this.selectedItem = currentItem
            this.selectedItemService.emit(currentItem)
        }
    }

    getCourseDetails() {
        this.isLoading = true;
        this.dashboardService.getCourseDetails(this.courseId).subscribe(
            res => {
                this.isLoading = false;
                this.handleCourseDetails(res)
            }
        )
        // this.showEnrollButton=true;
    }

    handleSubscriptionToCourse() {
        if (!this.isAlreadyEnrolled) {
            if (this.isEthrai && this.isCourseAvailabeInOtherTenants()) {
                this.showEnrollButton = true;
                return;
            }
            if ((this.isEthrai && this.course.course.pricing?.price && !this.course.course.isAlreadySubscribedToOne && !(this.course.course?.canAddToCart)) || !this.isEthrai) {
                this.showEnrollButton = true;
            } else if (this.isEthrai && this.course.course.pricing?.price && this.course.course.isAlreadySubscribedToOne && this.course.course?.canAddToCart) {
                if (this.paymentNotCompleted) {
                    if (isAndroid) {
                        this.paymentService.getShopCart().toPromise().then(
                            res => {
                                let products = res as any[];
                                this.isAlreadyInCart = products.some(product => product.productId === this.courseId);
                                if (this.isAlreadyInCart) {

                                } else {
                                    this.showCartButton = true;
                                }
                            },
                            err => {
                                console.log(err)
                            }
                        )
                    } else {
                        let requests = this.globalService.getInAppFailedRequests()
                        if (requests) {
                            let reqArray: any[] = JSON.parse(requests);
                            let currRequest = reqArray.find(req => req.productId == this.courseId)
                            if (currRequest) {
                                this.showProcessingButton = true;
                                // this.buyProducts(currRequest);
                            }

                        } else {
                            this.showAppleBuyButton = true;
                        }
                    }

                } else {
                    if (this.paymentCompleted) {
                        this.showEnrollButton = true;
                    } else {
                        this.showWaitButton = true;
                    }
                }
            } else {
                this.showEnrollButton = true;
            }
        } else {
            this.getCourseFinished();
        }
    }

    addToShoppingCart() {
        this.firebaseEventService.logCourseDetailsImpressionEvent("add_to_cart", 'course_page', this.course, this.selectedItem?.nameAr, this.loggedDuration, this.progressPercentage, this.getItemUnit(this.selectedItem))
        let product = {
            productId: this.courseId,
            amount: this.course.course?.pricing.price,
            productType: 'Course'
        }
        this.paymentService.addToShopCart(product).then(
            res => {
                if ((res as any).success) {
                    this.isAlreadyInCart = true
                    this.showCartButton = false;
                    this.globalService.shoppinCartItemsCount += 1;

                    //	this.productDetail= (res as any).extraData
                    // this.getShopCart();
                }
            },
            err => {
                this.showCartButton = true;
                console.log(err);
                this.globalService.toast(localize('tryAgain'))
            }
        );
    }

    enrollInCourse() {
        if (this.globalService.isLoggedIn) {
            if (this.paymentCompleted) {
                this.enroll()
            } else {
                if (this.isEthrai && this.isCourseAvailabeInOtherTenants()) {
                    this.globalService.toast(localize('CanYouEnrollFrom') + this.tenantName)

                } else if ((this.isEthrai && !this.isCourseAvailabeInOtherTenants())) {
                    if (this.globalService.getUserType() == 'SaudiTrainee' && !this.course.course.isAlreadySubscribedToOne) {

                        Dialogs.confirm({
                            title: localize('confirmEnroll'),
                            message: localize("freeProg") + this.course.course.remainingFreeCourses + localize("totalFreeProgs"),
                            okButtonText: localize('Yes'),
                            cancelButtonText: localize('No'),
                        }).then(result => {
                            if (result) {
                                this.enroll();
                            }
                        });
                    } else if (this.globalService.getUserType() == 'SaudiTrainee' && this.course.course.isAlreadySubscribedToOne) {
                        this.globalService.toast(localize('AlreadySubToOneSaudiTrainee'))
                    }
                    else {
                        this.enroll();
                    }
                } else if (!this.isEthrai) {
                    this.enroll()
                }
            }

        } else {
            this.globalService.toast(localize('noEnroll'))
        }

    }

    enroll() {
        this.dashboardService.enrollInCourse(this.courseId).subscribe(
            res => {
                if ((res as any).success) {
                    this.globalService.toast(localize('EnrollSuccess'))
                    this.showEnrollButton = false;
                    this.showCartButton = false;
                    this.showCertificateButton = false;
                    this.showWaitCertificateButton = false;
                    this.getCourseDetails();
                }

            },
            err => {
                this.globalService.toast(localize('EnrollFailure'))
                console.log("enroll errr", err)
            }
        )
    }

    isCourseAvailabeInOtherTenants(): boolean {
        let allowedCourseTenants: string[] = this.course.course.allowedTenantIds;
        let allowedCourseTenantsWithoutEthrai = allowedCourseTenants.filter(t => t != environment.ETHRAI_GUID);
        let userTenants: any[] = this.globalService.getUserTenants() ? this.globalService.getUserTenants() : JSON.parse(this.globalService.getTenants());
        if (userTenants?.length <= 1) {
            return false;
        } else {
            for (let i = 0; i < userTenants?.length; i++) {
                if (allowedCourseTenantsWithoutEthrai.includes(userTenants[i].id)) {
                    this.tenantName = userTenants[i]?.nameAr
                    return true;
                }
            }
        }
        return false;
    }
    goToShoppingCart() {
        this.router.navigate(['shopping-cart']);
    }

    downloadCertificate() {
        if (this.certificateURL) {
            Utils.openUrl(this.certificateURL);
        } else {
            Utils.openUrl(this.course.enrollment.certificate.url);
        }

    }


    getUserFeedbacks() {
        this.dashboardService.getUsersFeedbacksPerCourse(this.courseId, 0, 5).subscribe(
            res => {
                let feeds = res as any[]
                if (feeds?.length) {
                    feeds.forEach(element => {
                        this.feedbacks.push(element);
                    });
                }
            },
            err => {

            }
        )
    }

    onConsole(e: any) {
        console.log("consolle", e.data);
    }

    onloadFinished(args: LoadEventData) {
        if (!this.webview) { //to prevent creating new instances of webview when app sent to background
            this.webview = args.object;

            if (isIOS) {
                this.webview.ios.configuration.allowsInlineMediaPlayback = true
            }
            this.setWebViewSrc().then(
                res => {
                    this.webview.src = res;
                    //  this.webViewExt=this.webview;
                    // console.log("set webview sec",this.webViewExt.src)
                },
                err => {
                    console.log("err webview", err)

                }
            );
            this.webview.on("end", (msg) => {
                if (this.isAutoPlay) {
                    this.isVideoFinished = true;
                }
                if (this.globalService.isEthrai) {
                    this.firebaseEventService.logVideoStartedorCompletedEvent('course_videocompleted', 'course_page', this.course, this.selectedItem.nameAr, this.loggedDuration, this.progressPercentage, this.getItemUnit(this.selectedItem))
                }
                this.setCurrentElementInfo(this.currentVideoSecond);
                let selectedItemIndex = this.flattenedDetails.indexOf(this.selectedItem);
                if (selectedItemIndex + 1 < this.flattenedDetails?.length) {
                    this.selectedItem = this.flattenedDetails[selectedItemIndex + 1];
                    this.selectedItemService.emit(this.flattenedDetails[selectedItemIndex + 1])
                }
            });
            this.webview.on("percentwatchedchanged", (msg) => {
                this.setTrackedItem(this.selectedItem.id)
            });
            this.webview.on("pause", (msg: any) => {
                this.isVideoPlayed = false;
                this.setCurrentElementInfo(this.currentVideoSecond);
            });
            this.webview.on("timechange", (msg: any) => {
                this.currentVideoSecond = Math.round(msg.data)
            });
            this.webview.on("play", (msg: any) => {
                this.isVideoPlayed = true;
                if (this.globalService.isEthrai) {
                    this.firebaseEventService.logVideoStartedorCompletedEvent('course_videostarted', 'course_page', this.course, this.selectedItem.nameAr, this.loggedDuration, this.progressPercentage, this.getItemUnit(this.selectedItem))
                }
            });
        }
    }
    async setWebViewSrc(): Promise<string> {
        let f = knownFolders.documents();
        let folder = f.getFolder("app");
        let file = folder.getFile('local.html');
        let videoCode = this.url?.substring(this.url.lastIndexOf('/') + 1);
        let source;
        let secondsWatched = this.course.enrollment?.currentCourseDetailSecond
        source = new WebViewSource(videoCode, secondsWatched);

        await file.writeText(source.getHtmlString()).then(() => {
        }).catch((err) => {
            console.log(err);
        });
        return file.path;

    }

    setWebViewAliBabaSrc() {
        console.log('DEBUG setWebViewAliBabaSrc() called');
        const htmlString = this.Alibaba();

        if (htmlString.includes('No video sources')) return;

        const referer = "https://mobile.ethrai.sa";

        if (isIOS && (this.webview as any).ios) {
            console.log('DEBUG: Loading with Referer header on iOS');
            try {
                // Create a data URL from the HTML string
                const encodedHtml = encodeURIComponent(htmlString);
                const dataUrl = `data:text/html;charset=utf-8,${encodedHtml}`;

                // Create NSMutableURLRequest with Referer header
                const nsUrl = NSURL.URLWithString(dataUrl);
                const request = NSMutableURLRequest.requestWithURL(nsUrl);
                request.setValueForHTTPHeaderField(referer, "Referer");

                // Load the request with the custom header
                (this.webview as any).ios.loadRequest(request);
                console.log('DEBUG: iOS HTML loaded with Referer header');
            } catch (e) {
                console.error('DEBUG: iOS Referer header error:', e);
                // Fallback to standard loading
                (this.webview as any).src = htmlString;
            }
        } else if (isAndroid && (this.webview as any).android) {
            console.log('DEBUG: Loading with Referer header on Android');
            try {
                // Create a data URL from the HTML string
                const encodedHtml = encodeURIComponent(htmlString);
                const dataUrl = `data:text/html;charset=utf-8,${encodedHtml}`;

                // Create HashMap with Referer header
                const extraHeaders = new java.util.HashMap();
                extraHeaders.put("Referer", referer);

                // Enable JavaScript
                const settings = (this.webview as any).android.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setMediaPlaybackRequiresUserGesture(false);

                // Load URL with extra headers
                (this.webview as any).android.loadUrl(dataUrl, extraHeaders);
                console.log('DEBUG: Android HTML loaded with Referer header');
            } catch (e) {
                console.error('DEBUG: Android Referer header error:', e);
                // Fallback to standard loading
                (this.webview as any).src = htmlString;
            }
        } else {
            // Fallback for other cases
            console.log('DEBUG: Loading without custom Referer header');
            (this.webview as any).src = htmlString;
        }
    }
    onItemSelected() {
        this.getSubtitle(this.courseId);
        return this.selectedItemService.on().subscribe(
            res => {
                if (this.selectedItem?.type == 'Video' && this.currentVideoSecond) {
                    if (isIOS && this.webview) {
                        try {
                            (this.webview as any).ios?.evaluateJavaScriptCompletionHandler("Video.remove()", (result: any, error: any) => {
                                console.log("res on item selected", result);
                            });
                        } catch (e) { console.log('item selected JS error:', e); }
                    }
                }
                this.selectedItem = res;
                this.isVideoPlayed = false;
                this.setCurrentElementInfo(this.currentVideoSecond)
                if (!(this.selectedItem.isAvailableWithoutRegister) && !(this.isAlreadyEnrolled)) {
                    this.globalService.toast(localize('RegNeeded'))
                } else if (this.selectedItem.type == 'Pdf') {
                    this.url = (res as any).applicationUrl;
                    this.url = "http://docs.google.com/gview?embedded=true&url=" + this.url;
                } else if (this.selectedItem.type == 'Activity') {
                    this.url = (res as any).applicationUrl;
                }
                else if (this.selectedItem.type == 'Video') {
                    if (this.globalService.isEthrai || !this.globalService.isLoggedIn) {
                        this.firebaseEventService.logVideoStartedorCompletedEvent('course_videounitclicked', 'course_page',
                            this.course, this.selectedItem.nameAr, this.loggedDuration, this.progressPercentage, this.getItemUnit(this.selectedItem))

                    }

                    console.log('DEBUG: selectedItem.alibabaPlayInfo =', JSON.stringify(this.selectedItem.alibabaPlayInfo));
                    console.log('DEBUG: res.alibabaPlayInfo =', JSON.stringify((res as any).alibabaPlayInfo));
                    this.urlProtected = this.selectedItem.alibabaPlayInfo || (res as any).alibabaPlayInfo;
                    console.log('DEBUG: urlProtected =', JSON.stringify(this.urlProtected));
                    if (this.webview) {
                        this.setWebViewAliBabaSrc();
                    }

                } else if (this.selectedItem.type == 'SelfAssessment') {
                    this.assessmentQuestionsNo = this.selectedItem.assessment?.questions?.length
                    this.assessmentQuestions = this.selectedItem?.assessment?.questions;

                    this.showResult = false;
                    this.assessmentQuestionIndex = 0
                    this.assessmentProgressPercent = 0;
                    this.correctAnswersCount = 0
                }
                if (this.selectedItem.type != 'Video' && !this.course.enrollment?.trackings?.some(item => item.courseDetailId == this.selectedItem?.id)) {
                    this.setTrackedItem(this.selectedItem?.id);
                }
                // } 


            },
            err => {
                console.log("errr", err)
            }
        )

    }
    setTrackedItem(detailId) {
        if (this.isAlreadyEnrolled && !this.course.enrollment?.trackings?.some(item => item.courseDetailId == detailId)) {
            let body = {
                courseDetailId: detailId,
                courseInstanceToken: this.course.course.courseInstanceToken,
                enrollmentId: this.course.enrollment?.id
            }
            this.dashboardService.setCourseTracking(body).subscribe(
                res => {
                    if ((res as any).success) {
                        this.course.enrollment.trackings = (res as any).extraData.trackings;
                        this.attendedSeconds = (res as any).extraData.attendedSeconds
                        this.progressPercentage = ((this.attendedSeconds / this.course.course.numberOfSecondsRequiredToAttend) * 100)//.toFixed(2)
                        this.progressPercentage > 100 ? this.progressPercentage = 100 : this.progressPercentage = Number(this.progressPercentage.toFixed(2))
                        if ((res as any).extraData.status == 'Success') {
                            this.isCourseFinished = true;
                            if (!this.showCertificateButton && !this.showWaitCertificateButton) {
                                if (this.globalService.isEthrai) {
                                    this.firebaseEventService.logCourseCompletedEvent('course_page', this.course, this.selectedItem.nameAr, this.loggedDuration, this.progressPercentage
                                        , this.getItemUnit(this.selectedItem))
                                }
                                this.globalService.toast(localize('Congrats'))
                                this.openCourseRatingModal()
                            }

                            if (!this.course.course.disableCertification && this.showCertificates() && !this.showCertificateButton) {
                                this.showWaitCertificateButton = true;
                                this.checkCertificate();
                                // Certificate Ready Soon
                            } else {
                                console.log("finish", this.isCourseFinished, "show certs", this.showCertificates())
                            }
                        }
                    }
                },
                err => {

                }
            )
        }
    }


    getCourseFinished() {
        if (this.course.enrollment.status == 'Success') {
            this.isCourseFinished = true;
        }
        if (this.isCourseFinished && !this.course.course.disableCertification && this.showCertificates()) {
            if (this.course.enrollment.certificate.url) {
                this.showCertificateButton = true;
            } else {
                this.showWaitCertificateButton = true;
            }
        } else {
            // console.log("finish",this.isCourseFinished,"show certs",this.showCertificates())
        }
    }

    getShopCart() {
        this.paymentService.getShopCart().toPromise().then(
            res => {
                let products = res as any[];
                this.isAlreadyInCart = products.some(product => product.productId === this.courseId);
                if (this.isAlreadyInCart) {

                } else {
                    this.showCartButton = true;
                }
            },
            err => {
                console.log(err)
            }
        )
    }
    getText(html) {
        return html?.replace(/(<style[\w\W]+style>)/g, "").replace(/(<w:[\w\W]+\/>)/g, "").replace(/<[^>]+>/g, '').replace(/&nbsp;/g, '').replace(/\s+/g, " ")
    }
    shareCourse() {
        if (this.globalService.isEthrai || !this.globalService.isLoggedIn) {
            this.firebaseEventService.logShareClickedEvent("course_page")
        }
        share.shareUrl(this.course.course.shortUrl, "");
    }

    waitCertificate() {
        this.globalService.toast(localize('ContactSupportForCertificate'))
    }


    showCertificates() {
        let isForeginer = ['GulfCooperationCountries', 'Foreigner'].includes(this.globalService.getUserType());
        let isNameApproved = this.globalService.getUserProfile().namesApprovalStatus == 'Approved';
        if (isForeginer && !isNameApproved) {
            this.showWaitCertificateButton = true
            return false;
        }
        return true;
    }
    traverse(abc) {
        Object.entries(abc).forEach(([key, value]) => {
            if (key == "details") {
                let details = (value as any[]);
                if (details?.length > 0) {
                    for (let i = 0; i < details?.length; i++) {
                        if (details[i].type == 'Video' && (details[i].isAvailableWithoutRegister ||
                            (!this.course.details[i].isAvailableWithoutRegister && this.course.enrollment !== undefined))) {
                            this.selectedItemService.emit(details[i]);
                            this.selectedItem = details[i]
                            break;
                        } else if (details[i].type == 'Video' && !details[i].isAvailableWithoutRegister) {
                            break;
                        } else {
                            this.traverse(details[i]);
                        }
                    };
                } else {

                }

            }
        })
    }
    traverseById(abc) {
        Object.entries(abc).forEach(([key, value]) => {
            if (key == "details") {
                let details = (value as any[]);
                if (details?.length > 0) {
                    for (let i = 0; i < details?.length; i++) {
                        if (details[i].id == this.course.enrollment?.currentCourseDetailId) {
                            this.selectedItemService.emit(details[i])
                            this.selectedItem = details[i];
                            break;
                        } else {
                            this.traverseById(details[i]);
                        }
                    };
                } else {

                }

            }
        })
    }
    getNextQuestion() {
        this.isQuestionAnswered = false;
        if (this.assessmentQuestionIndex + 1 < this.assessmentQuestionsNo) {
            ++this.assessmentQuestionIndex;
        } else {
            this.showResult = true;
        }
        this.assessmentProgressPercent = Math.floor(((this.assessmentQuestionIndex + 1) / this.assessmentQuestionsNo) * 100);
        this.selectedAnswerId = undefined;
        this.correctAnswerId = undefined;
        this.isFirstAnswerAttempt = true
    }
    onSelectAnswer(answerId) {
        this.isQuestionAnswered = true
        if (this.isFirstAnswerAttempt) {
            this.selectedAnswerId = answerId
            this.correctAnswerId = this.assessmentQuestions[this.assessmentQuestionIndex]?.correctAnswer?.choiceId;
            if (this.selectedAnswerId == this.correctAnswerId) {
                this.correctAnswersCount += 1
            }
            this.correctAnswersPercentage = Math.floor((this.correctAnswersCount / this.assessmentQuestionsNo) * 100);
            this.isFirstAnswerAttempt = false
        }

    }

    // @HostListener('unloaded')
    ngOnDestroy() {
        this.clearSubscriptions()
    }
    clearSubscriptions() {
        if (this.subsVar) {
            this.subsVar.unsubscribe()
        }
        if (this.certSubscription) {
            this.certSubscription.unsubscribe()
        }
        if (isIOS) {
            //this.inAppPurchaseManager?.shutdown(); 
        }
    }
    setCurrentElementInfo(currentSecond: number) {
        if (this.isAlreadyEnrolled) {
            let payLoad = {
                enrollmentId: this.course?.enrollment?.id,
                currentCourseDetailId: this.selectedItem?.id,
                currentCourseDetailSecond: currentSecond
            }
            this.dashboardService.setVideoSeconds(payLoad).subscribe(
                res => {
                    this.course.enrollment.currentCourseDetailSecond = Math.round(this.currentVideoSecond)
                },
                err => {
                    console.log("err", err)

                }
            )
        }
    }
    goToCourse(id, course) {
        this.clearSubscriptions()
        if (isIOS && this.webview) {
            try {
                (this.webview as any).ios?.evaluateJavaScriptCompletionHandler("Video.remove()", (result: any, error: any) => {
                    this.webview = null;
                    console.log("res go to course", result);
                });
            } catch (e) { console.log('goToCourse JS error:', e); }
        }
        if (this.globalService.isEthrai || !this.globalService.isLoggedIn) {
            this.firebaseEventService.logCourseClickedEvent(this.globalService.isLoggedIn, this.globalService.getUserStats(),
                "course_page", this.globalService.getUserProfile(), course)
        }
        this.route.routeReuseStrategy.shouldReuseRoute = function () { return false }
        this.route.onSameUrlNavigation = 'reload'
        this.router.navigate(['/course-details', id])
    }
    // flattenDetailsTree(details,extractDetails){
    //     Array.prototype.concat.apply(
    //         details, 
    //         details.map(x => this.flattenDetailsTree(extractDetails(x) || [], extractDetails))
    //     );

    //     //   let extractDetails = x => x.details;

    //     //   let flat = flatten(extractDetails(tree), extractDetails)
    //                     //  .map(x => delete x.details && x);
    // }
    // extractDetails(tree){
    //     return x => x.details;
    // }
    flat(abc) {
        Object.entries(abc).forEach(([key, value]) => {
            if (key == "details") {
                let details = (value as any[]);
                if (details?.length > 0) {
                    for (let i = 0; i < details?.length; i++) {
                        if (details[i].type != 'Label') {
                            this.flattenedDetails.push(details[i])
                        } else if (details[i].type == 'Label') {
                            this.LabelsArray.push(details[i])
                        }
                        this.flat(details[i]);
                    };
                } else {
                }

            }
        })
    }
    openCourseRatingModal() {
        const response = this.modalService.showModal(CourseRatingModalComponent, {
            context: {
                dim: "#00000000",
                enrollmentId: this.course?.enrollment?.id,
                courseId: this.courseId
            },
            fullscreen: false,
            viewContainerRef: this.vcRef,
            dimAmount: 0.5,
        } as any);
        response.then(res => this.globalService.toast(localize('tryAgain')))
    }
    checkCertificate() {
        this.certSubscription = this.dashboardService.checkCertificate(this.course.enrollment?.id).pipe(
            map(res => {
                let url = (res as any).url
                if (!url) {
                    throw new Error("Invalid Value");
                }
                return res;
            }),
            retryWhen(
                error =>
                    error.pipe(
                        tap(() => console.log("error occurred ")),
                        delay(2000),
                        tap(() => console.log("Retrying ..."))
                    )
            )
        )
            .subscribe(
                res => {
                    this.showCertificateButton = true;
                    this.showWaitCertificateButton = false;
                    this.certificateURL = (res as any).url
                    console.log("checkCertificate url", res)
                },
                err => console.log(err),
            );
        // this.dashboardService.checkCertificate(this.course.enrollment.id).subscribe(
        //     res=>{
        //         console.log("checkCertificate",res);
        //         if((res as any).url){
        //             this.showCertificateButton=true;
        //             this.showWaitCertificateButton=false;
        //             this.certificateURL=(res as any).url
        //             console.log("checkCertificate url")
        //         }
        //     },
        //     err=>{
        //         console.log(err);
        //     }
        // )
    }

    //   getInAppPurchaseManager(){
    // 	const purchaseStateUpdateListener: InAppPurchaseStateUpdateListener = {
    // 		onUpdate: (purchaseTransactionState: InAppPurchaseTransactionState): void => {
    // 			if (purchaseTransactionState.resultCode === InAppPurchaseResultCode.Purchased) {
    //                 if(!this.isConfirmed){
    //                     this.confirmOrder(purchaseTransactionState);
    //                     this.isConfirmed=true;
    //                 }
    // 			}
    // 			if (purchaseTransactionState.resultCode === InAppPurchaseResultCode.Failed) {
    // 				console.log("PURCHASE FAIL");
    // 			}
    // 			if (purchaseTransactionState.resultCode === InAppPurchaseResultCode.Purchasing) {
    // 				console.log("PURCHASE INPROGRESS")
    // 			}
    // 		},
    // 		onUpdateHistory: (purchaseTransactionState: InAppPurchaseTransactionState): void => {
    // 			if (purchaseTransactionState.resultCode === InAppPurchaseResultCode.Restored) {
    // 				console.log("PURCHASE RESTORED")
    // 			}
    // 		}
    // 		}
    // 		InAppPurchaseManager.bootStrapInstance(purchaseStateUpdateListener).then(inAppPurchaseManager => {
    // 			this.inAppPurchaseManager = inAppPurchaseManager
    // 		})
    // 	}
    // 	queryProducts() {
    //         let courseArr=[];
    //         courseArr.push(this.course)
    //         this.firebaseEventService.logCheckoutBeginEvent('course_page',courseArr)
    //         this.firebaseEventService.logPaymentInfoEvent('course_page',courseArr,'apple_in_app_purchase')
    //         this.paymentService.getSiteMaintenanceState().subscribe(
    //             res=>{
    //                 if(res){
    //                     this.globalService.toast(localize('underMaintenance'))
    //                 }else{
    //                     const myProductIds = [this.course.course.appleProductId] //['sa.ethrai_mobile.app.tire2']
    //                     const myProductType = InAppPurchaseType.InAppPurchase 
    //                     this.isQueryProduct=true;
    //                     this.inAppPurchaseManager.list(myProductIds, myProductType)
    //                         .then(
    //                             (result: InAppListProductsResult) => {
    //                             this.isQueryProduct=false;
    //                             const product:
    //                              InAppProduct = result.products[0]
    //                             if(product){
    //                                 // get the products ...
    //                                 this.inAppPurchaseManager.order(product).then(
    //                                     (result: InAppOrderResult) => {
    //                                     if (result.success) {

    //                                     }
    //                                 },
    //                                 err=>{console.log(err)}
    //                                 )

    //                             }else{
    //                                 const toast = new Toasty({ text: localize('tryAgain') ,yAxisOffset: 50});
    //                                 toast.show();
    //                             }
    //                             }
    //                         ,err=>{
    //                             this.isQueryProduct=false;
    //                             console.log("kkkkkkkkkkk",err)
    //                         }

    //                         )
    //                             }
    //                 }
    //             )
    // 	}
    // 	confirmOrder(purchaseTransactionState: InAppPurchaseTransactionState) {
    //         const isConsumable = (productId: string): boolean => { 
    //             /* determine if is consumable and can be purchased more then once */
    //             return true }
    //             // alert("Confirm Order")
    //         // only purchased products can be confirmed

    //         if (purchaseTransactionState.resultCode === InAppPurchaseResultCode.Purchased) {
    //             const consumable: boolean = isConsumable(purchaseTransactionState.productIdentifier)
    //             this.inAppPurchaseManager.orderConfirm(purchaseTransactionState, consumable)
    //                 .then((result: InAppOrderConfirmResult) => {
    //                     if (result.success) {
    //                         let payload=
    //                         {
    //                             productId: this.course.course.id,
    //                             productType: "Course",
    //                             appleProductId: this.course.course.appleProductId,
    //                             transactionReceipt:this.inAppPurchaseManager.getStoreReceipt()
    //                         }
    //                         this.buyProducts(payload)
    //                     }else{
    //                         // alert("order confirmation FAILED")
    //                     }
    //                 })//.catch(err=>alert(err))

    //         }
    //     //    alert("confirm order method finished") 
    //     }

    //     buyProducts(payload){
    //         const type = Connectivity.getConnectionType();
    //         if(type == Connectivity.connectionType.none){
    //             this.globalService.toast(localize('proceessing'));
    //             this.globalService.setInAppFailedRequests(payload);
    //             this.zone.run(()=>{
    //                 this.showAppleBuyButton=false;
    //                 this.showProcessingButton=true;
    //             })
    //         }else{
    //             this.paymentService.getSiteMaintenanceState().subscribe(
    //                 res=>{
    //                     if(res){
    //                         this.globalService.toast(localize('processingLater'));
    //                         this.globalService.setInAppFailedRequests(payload);
    //                         this.zone.run(()=>{
    //                             this.showAppleBuyButton=false;
    //                             this.showProcessingButton=true;
    //                         })
    //                     }else{
    //                         this.paymentService.postAppleOrder(payload).subscribe(
    //                             res=>{
    //                                 let response= res as any
    //                                 if(response.success){
    //                                     this.zone.run(()=>{
    //                                         this.showEnrollButton=true;
    //                                         this.showAppleBuyButton=false;
    //                                         this.paymentCompleted=true;
    //                                         this.showProcessingButton=false;
    //                                         let courseArr=[];
    //                                         courseArr.push(this.course)
    //                                         this.firebaseEventService.logPurchaseEvent('course_page',courseArr,'apple_in_app_purchase',this.inAppPurchaseManager.getStoreReceipt(),'','na')
    //                                     });
    //                                     this.globalService.toast(localize('EnrollSuccess'));
    //                                     this.globalService.editInAppFailedRequests(payload)
    //                                 }
    //                             },
    //                             err=>{
    //                                 this.globalService.toast(localize('proceessing'));
    //                                 this.globalService.setInAppFailedRequests(payload);
    //                                 this.zone.run(()=>{
    //                                     this.showAppleBuyButton=false;
    //                                     this.showProcessingButton=true;
    //                                 })

    //                             }
    //                         )
    //                     }
    //             })
    //         }
    //         // this.page.on(Page.unloadedEvent, event => {
    //         //     alert("unloadedEvent")
    //         //     this.ngOnDestroy();
    //         // })

    //     }
    getItemUnit(item) {
        let itm = item
        while (itm?.parentId) {
            itm = this.LabelsArray.find(i => i.id == itm?.parentId)
        }
        return itm?.nameAr
    }
    getCourseProgressPercent(watchedSeconds: number, TotalSeconds: number) {
        if (!TotalSeconds) return 0;
        return Math.round((watchedSeconds / TotalSeconds) * 100);
    }
    toggleFavorite(id, item, isFavorite) {
        if (this.globalService.isLoggedIn) {
            let payload = {
                "productId": id,
                "type": "Course"
            }
            if (!isFavorite) {
                this.dashboardService.setFavoriteProducts(payload).subscribe(
                    res => {
                        if ((res as any).success) {
                            item.isFavorite = true;
                            this.globalService.toast(localize('FavAdded'));
                            if (this.isEthrai) {
                                this.firebaseEventService.logAddToWishListEvent('course_page', this.course, this.selectedItem?.nameAr, this.loggedDuration, this.progressPercentage, this.getItemUnit(this.selectedItem))
                            }
                        }
                    },
                    err => {

                    }
                )
            } else {
                this.dashboardService.removeFavoriteProducts(payload).subscribe(
                    res => {
                        item.isFavorite = false;
                        if ((res as any).success) {
                            this.globalService.toast(localize('FavRemoved'))
                        }
                    },
                    err => {

                    }
                )
            }
        } else {
            this.globalService.toast(localize('LogNeededFav'))
        }
    }
    showFeedback(e) {
        if (e) {
            this.feedbacks.push(e);
        }
        this.showReviewForm = false;
    }
    setSelectedTabIndex(e: SelectedIndexChangedEventData) {
        this.selectedTabIndex = e.newIndex
    }

}


