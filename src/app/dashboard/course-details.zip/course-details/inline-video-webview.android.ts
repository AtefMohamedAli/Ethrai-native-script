// Android version - just re-export the standard WebView
import { WebView } from '@nativescript/core';

export { WebView as InlineVideoWebView };
