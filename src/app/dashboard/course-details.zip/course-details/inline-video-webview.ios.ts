import { WebView } from '@nativescript/core';

declare const WKWebViewConfiguration: any;
declare const WKWebView: any;
declare const CGRectZero: any;

/**
 * iOS-specific WebView that enables inline video playback.
 * The key is to configure WKWebViewConfiguration BEFORE creating the WKWebView.
 */
export class InlineVideoWebView extends WebView {

    createNativeView(): any {
        // Create a new configuration with inline media playback enabled
        const configuration = WKWebViewConfiguration.new();

        // Enable inline playback (prevents fullscreen)
        configuration.allowsInlineMediaPlayback = true;

        // Don't require user action for media playback (allows autoplay)
        // 0 = WKAudiovisualMediaTypeNone
        configuration.mediaTypesRequiringUserActionForPlayback = 0;

        // Allow AirPlay
        configuration.allowsAirPlayForMediaPlayback = true;

        // Create WKWebView with the configured configuration
        const webView = WKWebView.alloc().initWithFrameConfiguration(CGRectZero, configuration);

        return webView;
    }
}
