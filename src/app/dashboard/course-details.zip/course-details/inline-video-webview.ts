import { WebView } from '@nativescript/core';
import { isIOS } from '@nativescript/core';

declare const WKWebViewConfiguration: any;
declare const WKWebView: any;
declare const CGRectZero: any;

/**
 * Custom WebView class that enables inline video playback on iOS.
 * By default, iOS WKWebView plays videos in fullscreen mode.
 * 
 * IMPORTANT: WKWebViewConfiguration MUST be set BEFORE the WKWebView is created.
 * You cannot modify configuration.allowsInlineMediaPlayback after creation.
 */
export class InlineVideoWebView extends WebView {

    createNativeView(): Object {
        if (isIOS) {
            // iOS: Must create WKWebView with pre-configured WKWebViewConfiguration
            try {
                // Create a new configuration with inline media playback enabled
                const configuration = WKWebViewConfiguration.new();

                // Enable inline playback (prevents fullscreen)
                configuration.allowsInlineMediaPlayback = true;

                // Don't require user action for media playback (allows autoplay)
                // 0 = WKAudiovisualMediaTypeNone
                configuration.mediaTypesRequiringUserActionForPlayback = 0;

                // Allow AirPlay
                configuration.allowsAirPlayForMediaPlayback = true;

                console.log('InlineVideoWebView: Creating WKWebView with inline playback configuration');

                // Create WKWebView with the configured configuration
                const webView = WKWebView.alloc().initWithFrameConfiguration(CGRectZero, configuration);

                return webView;
            } catch (e) {
                console.error('InlineVideoWebView: Failed to create custom WKWebView:', e);
                // Fallback to default WebView
                return super.createNativeView();
            }
        } else {
            // Android: Use default WebView
            return super.createNativeView();
        }
    }
}
